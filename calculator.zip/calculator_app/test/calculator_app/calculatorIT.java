/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculator_app;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author santhiya
 */
public class calculatorIT {
    
    public calculatorIT() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of arithmetic_operation method, of class calculator.
     */
   @Test
    public void testArithmetic_operation() {
        System.out.println("arithmetic_operation");
        calculator instance = new calculator();
        instance.arithmetic_operation();
        calculator_app.calculator calc=new calculator_app.calculator();
        
      
      
      
        
        
    }

    /**
     * Test of enable method, of class calculator.
     */
    @Test
    public void testEnable() {
        System.out.println("enable");
        calculator instance = new calculator();
        instance.enable();
        // TODO review the generated test code and remove the default call to fail.
       
    }

    /**
     * Test of disable method, of class calculator.
     */
    @Test
    public void testDisable() {
        System.out.println("disable");
        calculator instance = new calculator();
        instance.disable();
        // TODO review the generated test code and remove the default call to fail.
     
    }

    /**
     * Test of main method, of class calculator.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        calculator.main(args);
        // TODO review the generated test code and remove the default call to fail.
     
    }
    
}
